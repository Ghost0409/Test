### _NOTE: This extension is unmaintained!_

# Java Server Pages (JSP) for Visual Studio Code

JSP language support for Visual Studio Code, ported from TextMate's JSP bundle.
https://github.com/textmate/java.tmbundle

As stated above, **_this extension is NOT maintained_**. Feel free to fork it and publish it.
https://github.com/pthorsson/vscode-jsp
